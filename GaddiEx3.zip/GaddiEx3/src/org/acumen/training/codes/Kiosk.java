package org.acumen.training.codes;

public class Kiosk {

	private double prevBal;
	private double addCharge;
	private double newBal;
	private double interest;
	private double minPay;

	public void computeCharge(double prevBalance, double addChg) {

		prevBal = prevBalance; //or we can use the keyword this 
		addCharge = addChg;

		if (prevBal > 0) {
			interest = (prevBal + addCharge) * 0.02;
		} else {
			interest = 0;
		}

		newBal = prevBal + addCharge + interest;
		computeMinPay(newBal);
	}

	private void computeMinPay(double newBal) {

		if (newBal <= 50) {
			minPay = newBal;
		} else if (newBal > 50 && newBal < 300) {
			minPay = 50.00;
		} else {
			minPay = newBal * 0.20;
		}

	}

	public void printAmount() {
		char dollar = 0x24;

		System.out.println("CS CARD International Statement");
		System.out.println("===============================");
		System.out.println();
		System.out.println("Previous Balance:\t" + dollar + prevBal);
		System.out.println("Additional Charges:\t" + dollar + addCharge);
		System.out.println("Interest:\t\t" + dollar + interest);
		System.out.println();
		System.out.println("New Balance:\t\t" + dollar + newBal);
		System.out.println();
		System.out.println("Minimum Payment:\t" + dollar + minPay);

	}
}
