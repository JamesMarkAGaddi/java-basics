package org.acumen.training.codes;

public class TestBadNews {
	public static void main(String[] args) {
		BadNews bad = new BadNews();
		bad.run();
	}
}
