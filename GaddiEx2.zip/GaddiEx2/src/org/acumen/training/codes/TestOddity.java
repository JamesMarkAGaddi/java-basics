package org.acumen.training.codes;

public class TestOddity {

	public static void main(String[] args) {

		System.out.println(Oddity.allDigitsOdd(135319));
		System.out.println(Oddity.allDigitsOdd(9145293));
		System.out.println(Oddity.allDigitsOdd(135));
		System.out.println(Oddity.allDigitsOdd(2468));
		System.out.println(Oddity.allDigitsOdd(27));
	}
}
