package org.acumen.training.codes;

public class BadNews {
	public static int MAX_ODD = 21;

	public static void writeOdds() {
		for (int count = 1; count <= MAX_ODD;) { // print each odd number
			System.out.print(count + " ");
			count = count + 2;
		}
		System.out.println();
	}

	public void run() {
		writeOdds();  // write all odds up to 21
		MAX_ODD = 11; // now, write all odds up to 11
		writeOdds();
	}
}