/* 
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.coded;

public class WellDoneFormat{
	
	public static void main(String[] args) {
		System.out.println("\\\"");
	}
}