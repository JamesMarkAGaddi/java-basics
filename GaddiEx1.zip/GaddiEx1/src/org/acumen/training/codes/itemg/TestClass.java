/* 
	Description: This program will test the Fraction class and its methods
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itemg;

public class TestClass {
	public static void main(String[] args) {

		Fraction f1 = new Fraction(10, 23);
		Fraction f2 = new Fraction(2, 3);

		f1.printRational();
		f2.multiply(f1).printRational();
		f2.add(f1).printRational();
		System.out.println(f2.greaterEqual(f1));

	}
}
