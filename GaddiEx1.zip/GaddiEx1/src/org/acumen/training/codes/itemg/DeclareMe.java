/* 
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itemg;

public class DeclareMe {

	public static void main(String[] args) {
		float f;
		int k = 22;
		f = k;

		System.out.println("k = " + k + "\nf = " + f);
	}
}
