/* 
	Description: This program computes the total state tax and country tax
	then computes the total cost of the item.
	
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itemb;

public class TestSalesTax {

	public static double STATE_TAX = .04;
	public static double COUNTRY_TAX = .02;

	public static void main(String[] args) {
		double amountA = 190.21;
		double amountB = 9123.22;
		double amountC = 98.00;
		double amountD = 1312.23;

		computeCost(amountA);
		computeCost(amountB);
		computeCost(amountC);
		computeCost(amountD);

	}
	/*
	 * Description: computes the taxes and total cost
	 */
	public static void computeCost(double itemCost) {
		double stateTax = itemCost * STATE_TAX;
		double countryTax = itemCost * COUNTRY_TAX;
		double totalCost = itemCost + stateTax + countryTax;

		System.out.println("Item Cost: " + itemCost);
		System.out.println("State Tax: " + stateTax);
		System.out.println("Country Tax: " + countryTax);
		System.out.println("Total Cost: " + totalCost + "\n");
	}

}
