/* 
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class TrickyOne{

	public static void main(String[] args) {
		System.out.println("Hello world");
		System.out.println("Do you like this program?");
		System.out.println();
		System.out.println("I wrote it myself.");
	}
}
