/* 
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class Exercise {
	//private int x = 101;

	private void storeValue(int x) {
		x++;
		printValue(x);
	}

	private void printValue(int x) {
		System.out.println(x);
	}

	public static void main(String[] args) {
		int x = 200;
		
		Exercise exercise = new Exercise();
		exercise.storeValue(x);
	}
}
