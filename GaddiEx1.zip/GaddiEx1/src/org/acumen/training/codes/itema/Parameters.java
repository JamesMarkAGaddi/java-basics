/* 
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class Parameters {

	public static void main(String[] args) {
		double bubble = 867.5309;
		double x = 10.01;
		double y = 0;
		double z = 0;

		printInputs(x, y);
		printInputs1(bubble);
		printInputsName("barrack", "obama");
		System.out.println("z = " + z);
	}

	public static void printInputs(double x, double y) {
		System.out.println("x = " + x + " and y = " + y);
	}
	public static void printInputs1(double bubble) {
		System.out.println("The value from main is: " + bubble);
	}
	public static void printInputsName(String name, String surname) {
		System.out.println(name +" "+ surname);
	}
	
}
