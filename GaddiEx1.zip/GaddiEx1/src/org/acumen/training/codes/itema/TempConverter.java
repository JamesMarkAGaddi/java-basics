/* 
	Description: This program converts temperature from Farenheit to Celcius
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class TempConverter {

	public static void main(String[] args) {
		double tempf = 98.6;
		double tempc = 0.0;

		tempc = convertTemp(tempf);
		System.out.println("Body temp in C is: " + tempc);
	}

	/*
	 * returns converted value
	 */
	public static double convertTemp(double tempf) {
		return (tempf - 32) * 5 / 9;
	}
}