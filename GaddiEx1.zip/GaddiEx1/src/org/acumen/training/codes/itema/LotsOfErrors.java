/* 
	Description:
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class LotsOfErrors {

	public static void main(String[] args) {
		System.out.println("Hello, world!");
		message();
	}

	public static void message() {
		System.out.println("This program surely cannot");
		System.out.println("have any so-called \"errors\" in it");
	}
}
