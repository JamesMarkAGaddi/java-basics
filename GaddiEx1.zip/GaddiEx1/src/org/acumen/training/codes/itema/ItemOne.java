/* 
	Description: This program will tell which number is smaller
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class ItemOne {

	public static void main(String args[]) {
		int a = 7;
		int b = 42;
		int smaller = showMinimum(a, b);

		if (smaller == a) {
			System.out.println("a is the smallest!");
		} else if (smaller == b) {
			System.out.println("b is the smallest!");
		}
	}

	/*
	 * returns which number is smaller
	 */
	public static int showMinimum(int a, int b) {
		int smaller = 0;
		if (a < b) {
			smaller = a;
		} else if (b < a) {
			smaller = b;
		}
		return smaller;
	}
}
