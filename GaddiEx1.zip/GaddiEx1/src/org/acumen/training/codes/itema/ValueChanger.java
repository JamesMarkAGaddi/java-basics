/* 
	Author: James Mark A. Gaddi
	Date: September 20, 2024
*/
package org.acumen.training.codes.itema;

public class ValueChanger {

	public static void main(String[] args) {
		int x = 0;

		System.out.println("x is " + x);
		float x1 = (float) 15.2; // set x to 15.2

		System.out.println("x is now " + x1);
		float y = x1 + 1; // set y to 1 more than x

		System.out.println("x and y are " + x1 + " and " + y);
	}
}
