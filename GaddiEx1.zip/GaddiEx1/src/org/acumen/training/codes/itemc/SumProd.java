package org.acumen.training.codes.itemc;

/**************************************************************
 * Description: This program displays the sum and product of 2 integers
 **************************************************************/

public class SumProd {

	public static void main(String[] args) {
		final int INT2 = 8;
		final int INT1 = 20;
		int sum = INT1 + INT2;
		System.out.println("The sum of " + INT1 + " and " + INT2 + " is " + sum);
		System.out.println("Their product is " + (INT1 * INT2));
	}
}